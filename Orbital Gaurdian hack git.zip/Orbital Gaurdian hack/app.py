"""
app.py  –  Orbital Guardian
AI-Powered Space Debris Detection, Tracking & Collision Prevention
Team LEGION  |  ASTRAVA Hackathon 2024

PERFORMANCE FIXES vs original:
1. fetch_tle_group() wrapped in @st.cache_data(ttl=300) — called ONCE per 5 min
2. load_data() cached with @st.cache_data(ttl=30) — no redundant ML training
3. Trajectory: predict_trajectory() result stored in session_state — not called twice
4. Altitude profile uses cached trajectory data (no second SGP4 propagation)
5. auto_refresh: uses st.rerun() properly — no blocking time.sleep()
6. RF model is module-level singleton in predictor.py — trains once per process
7. IsolationForest on trajectory: n_estimators=50 (not 150) for small datasets
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime, timezone, timedelta
import time

from data_fetcher import (
    fetch_tle_group, get_positions_df, GROUPS, compute_collision_risks
)
from predictor import (
    detect_anomalies, enrich_risks_with_ml,
    predict_trajectory, find_overpasses, orbital_stats
)

# ══════════════════════════════════════════════════════════════════════════════
# PAGE CONFIG
# ══════════════════════════════════════════════════════════════════════════════
st.set_page_config(
    page_title="Orbital Guardian",
    page_icon="🛰️",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Share+Tech+Mono&family=Exo+2:wght@300;400;600&display=swap');

html, body, [class*="css"] {
    background-color: #030712 !important;
    color: #e2e8f0 !important;
    font-family: 'Exo 2', sans-serif !important;
}
.stApp { background: #030712; }
.stApp::before {
    content:""; position:fixed; top:0; left:0; width:100%; height:100%;
    background: repeating-linear-gradient(0deg,transparent,transparent 2px,rgba(0,255,136,0.012) 2px,rgba(0,255,136,0.012) 4px);
    pointer-events:none; z-index:9999;
}
[data-testid="stSidebar"] {
    background: linear-gradient(180deg,#0a0f1e 0%,#050a14 100%) !important;
    border-right: 1px solid #00ff8833 !important;
}
.og-title {
    font-family:'Orbitron',monospace; font-size:2.4rem; font-weight:900;
    background:linear-gradient(135deg,#00ff88 0%,#00d4ff 50%,#7c3aed 100%);
    -webkit-background-clip:text; -webkit-text-fill-color:transparent;
    letter-spacing:0.08em; line-height:1.1;
}
.og-sub {
    font-family:'Share Tech Mono',monospace; font-size:0.75rem;
    color:#00ff8888; letter-spacing:0.15em; margin-top:4px;
}
.metric-card {
    background:linear-gradient(135deg,#0d1b2a 0%,#0a1628 100%);
    border:1px solid #1e3a5f; border-top:2px solid #00ff88;
    border-radius:12px; padding:18px 22px; position:relative; overflow:hidden;
}
.metric-card .label {
    font-family:'Share Tech Mono',monospace; font-size:0.68rem;
    color:#4a9eff; letter-spacing:0.15em; text-transform:uppercase;
}
.metric-card .value {
    font-family:'Orbitron',monospace; font-size:1.8rem; font-weight:700;
    color:#00ff88; line-height:1.2; margin:4px 0;
}
.metric-card .delta { font-size:0.7rem; color:#64748b; }

.alert-critical {
    background:linear-gradient(135deg,#2d0a0a,#1a0505);
    border:1px solid #ff3333; border-left:4px solid #ff0000;
    border-radius:8px; padding:14px 18px; margin:8px 0;
    font-family:'Share Tech Mono',monospace; font-size:0.82rem;
    animation:pulse-red 2s ease-in-out infinite;
}
.alert-high {
    background:linear-gradient(135deg,#2d1a0a,#1a0f05);
    border:1px solid #ff8800; border-left:4px solid #ff6600;
    border-radius:8px; padding:14px 18px; margin:8px 0;
    font-family:'Share Tech Mono',monospace; font-size:0.82rem;
}
.alert-safe {
    background:linear-gradient(135deg,#0a2d1a,#051a0f);
    border:1px solid #00ff88; border-left:4px solid #00cc66;
    border-radius:8px; padding:14px 18px;
    font-family:'Share Tech Mono',monospace; font-size:0.82rem;
}
@keyframes pulse-red { 0%,100%{box-shadow:0 0 8px #ff000033} 50%{box-shadow:0 0 20px #ff000066} }

.section-header {
    font-family:'Orbitron',monospace; font-size:1rem; font-weight:700;
    color:#00d4ff; letter-spacing:0.1em;
    border-bottom:1px solid #1e3a5f; padding-bottom:8px; margin-bottom:16px;
}
.stTabs [data-baseweb="tab-list"] { background:#0a0f1e; border-bottom:1px solid #1e3a5f; gap:4px; }
.stTabs [data-baseweb="tab"] {
    font-family:'Orbitron',monospace !important; font-size:0.7rem !important;
    color:#4a9eff !important; border-radius:6px 6px 0 0 !important; padding:8px 16px !important;
}
.stTabs [aria-selected="true"] {
    background:linear-gradient(180deg,#0d2040,#0a1628) !important;
    color:#00ff88 !important; border-top:2px solid #00ff88 !important;
}
.stButton > button {
    background:linear-gradient(135deg,#00ff8822,#00d4ff11) !important;
    border:1px solid #00ff8866 !important; color:#00ff88 !important;
    font-family:'Orbitron',monospace !important; font-size:0.72rem !important;
    letter-spacing:0.1em !important; border-radius:6px !important;
}
.stButton > button:hover { box-shadow:0 0 16px #00ff8833 !important; }
.live-dot {
    display:inline-block; width:8px; height:8px;
    background:#00ff88; border-radius:50%;
    animation:blink 1.2s ease-in-out infinite; margin-right:6px;
}
@keyframes blink { 0%,100%{opacity:1} 50%{opacity:0.2} }
.sidebar-logo {
    font-family:'Orbitron',monospace; font-size:1.1rem; font-weight:900;
    color:#00ff88; text-align:center; padding:10px 0 4px; letter-spacing:0.12em;
}
.sidebar-tag {
    font-family:'Share Tech Mono',monospace; font-size:0.62rem; color:#4a9eff;
    text-align:center; letter-spacing:0.1em; margin-bottom:16px;
}
.info-box {
    background:#0a1628; border:1px solid #1e3a5f; border-left:3px solid #00d4ff;
    border-radius:6px; padding:10px 14px; margin:6px 0;
    font-family:'Share Tech Mono',monospace; font-size:0.75rem; color:#94a3b8;
}
</style>
""", unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════════════════════
# CACHED DATA FETCHERS
# CRITICAL: These @st.cache_data wrappers prevent redundant network calls
# and model training. fetch_tle is called 3x in this app — caching saves 2 calls.
# ══════════════════════════════════════════════════════════════════════════════

@st.cache_data(ttl=300, show_spinner=False)
def cached_fetch_tle(group_key: str) -> list:
    """Cached TLE fetch — refreshes every 5 minutes."""
    return fetch_tle_group(group_key)


@st.cache_data(ttl=30, show_spinner=False)
def load_data(group_key: str, limit: int, thresh: float):
    """
    Main data pipeline: fetch TLEs → compute positions → AI analysis.
    Cached for 30 seconds so rapid interactions don't re-run everything.
    """
    df = get_positions_df(group_key, limit=limit)
    if df.empty:
        return df, [], {}
    df = detect_anomalies(df, n_estimators=150)   # full fleet — 150 trees ok
    df, pairs = compute_collision_risks(df, threshold_km=thresh)
    pairs = enrich_risks_with_ml(df, pairs)        # RF model cached in predictor.py
    stats = orbital_stats(df)
    return df, pairs, stats


# ══════════════════════════════════════════════════════════════════════════════
# SIDEBAR
# ══════════════════════════════════════════════════════════════════════════════
with st.sidebar:
    st.markdown('<div class="sidebar-logo">⬡ ORBITAL<br>GUARDIAN</div>', unsafe_allow_html=True)
    st.markdown('<div class="sidebar-tag">AI SPACE SITUATIONAL AWARENESS</div>', unsafe_allow_html=True)
    st.markdown("---")

    group_key = st.selectbox("🛰️ Satellite Group", list(GROUPS.keys()))

    st.markdown("---")
    st.markdown("**⚙️ Analysis Settings**")
    collision_thresh = st.slider("Collision Threshold (km)", 20, 500, 200)
    pred_minutes     = st.slider("Prediction Window (min)", 30, 180, 90)
    sat_limit        = st.slider("Max Satellites", 10, 80, 50)

    st.markdown("---")
    st.markdown("**📍 Your Location**")
    obs_lat = st.number_input("Latitude",  value=17.44, min_value=-90.0,  max_value=90.0,  step=0.1)
    obs_lon = st.number_input("Longitude", value=78.49, min_value=-180.0, max_value=180.0, step=0.1)

    st.markdown("---")
    auto_refresh = st.toggle("🔄 Auto Refresh (30s)", value=False)

    st.markdown("""
    <div style='font-family:Share Tech Mono,monospace;font-size:0.6rem;color:#334155;line-height:2'>
    DATA SOURCES<br>
    ▸ CelesTrak (Live TLE)<br>
    ▸ SGP4 Propagator (NASA)<br>
    ▸ Built-in fallback TLEs<br><br>
    AI MODELS<br>
    ▸ Isolation Forest (fleet)<br>
    ▸ Random Forest (collision)<br>
    ▸ 3D ECI Proximity<br><br>
    TEAM LEGION · ASTRAVA 2024
    </div>
    """, unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════════════════════
# HEADER
# ══════════════════════════════════════════════════════════════════════════════
h1, h2 = st.columns([4, 1])
with h1:
    now_str = datetime.now(timezone.utc).strftime("%Y-%m-%d  %H:%M:%S UTC")
    st.markdown(f"""
    <div class="og-title">ORBITAL GUARDIAN</div>
    <div class="og-sub"><span class="live-dot"></span>LIVE · AI SPACE DEBRIS DETECTION & COLLISION PREVENTION · {now_str}</div>
    """, unsafe_allow_html=True)
with h2:
    if st.button("⟳  REFRESH DATA", type="primary"):
        st.cache_data.clear()
        st.rerun()

st.markdown("<div style='height:14px'></div>", unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════════════════════
# LOAD DATA (cached — fast on subsequent renders)
# ══════════════════════════════════════════════════════════════════════════════
with st.spinner("⟳  Fetching orbital data & running AI analysis..."):
    df, risk_pairs, stats = load_data(group_key, sat_limit, collision_thresh)

if df.empty:
    st.error("⚠️  No satellite data available. Check your internet connection.")
    st.stop()


# ══════════════════════════════════════════════════════════════════════════════
# METRIC ROW
# ══════════════════════════════════════════════════════════════════════════════
m1, m2, m3, m4, m5 = st.columns(5)
for col, label, value, delta in [
    (m1, "🛰️ TRACKED",     stats.get("total", 0),            "satellites"),
    (m2, "🔴 RISK PAIRS",  len(risk_pairs),                   f"within {collision_thresh}km"),
    (m3, "⚡ AVG SPEED",   f"{stats.get('avg_speed', 0)} km/s", "orbital velocity"),
    (m4, "📏 AVG ALT",     f"{stats.get('avg_alt_km', 0)} km",  "LEO/MEO mean orbit"),
    (m5, "⚠️ ANOMALIES",  stats.get("anomalies", 0),          "AI-flagged"),
]:
    with col:
        st.markdown(f"""
        <div class="metric-card">
            <div class="label">{label}</div>
            <div class="value">{value}</div>
            <div class="delta">{delta}</div>
        </div>""", unsafe_allow_html=True)

st.markdown("<div style='height:18px'></div>", unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════════════════════
# TABS
# ══════════════════════════════════════════════════════════════════════════════
tab1, tab2, tab3, tab4, tab5 = st.tabs([
    "🌍  LIVE GLOBE",
    "⚠️  COLLISION RISKS",
    "🔮  TRAJECTORY AI",
    "📡  OVERPASS FINDER",
    "📊  ANALYTICS",
])


# ── TAB 1: LIVE GLOBE ─────────────────────────────────────────────────────────
with tab1:
    lc1, lc2 = st.columns([3, 1])
    with lc1:
        st.markdown('<div class="section-header">REAL-TIME SATELLITE POSITIONS  ·  SGP4 PROPAGATED</div>', unsafe_allow_html=True)

        color_map = {"🟢 SAFE": "#00ff88", "🟡 MEDIUM": "#ffcc00", "🟠 HIGH": "#ff8800", "🔴 CRITICAL": "#ff2222"}
        size_map  = {"🟢 SAFE": 6, "🟡 MEDIUM": 9, "🟠 HIGH": 13, "🔴 CRITICAL": 16}

        fig = go.Figure()
        for level, color in color_map.items():
            if "risk_level" in df.columns:
                sub = df[df["risk_level"] == level]
            else:
                sub = df if level == "🟢 SAFE" else pd.DataFrame()
            if sub.empty:
                continue
            fig.add_trace(go.Scattergeo(
                lat=sub["lat"], lon=sub["lon"],
                mode="markers",
                marker=dict(size=size_map[level], color=color, opacity=0.9,
                            line=dict(color="white", width=0.5)),
                name=level,
                hovertemplate=(
                    "<b>%{customdata[0]}</b><br>"
                    "Lat: %{lat:.2f}°  Lon: %{lon:.2f}°<br>"
                    "Alt: %{customdata[1]} km  |  Speed: %{customdata[2]} km/s<br>"
                    "Status: %{customdata[3]}<extra></extra>"
                ),
                customdata=list(zip(
                    sub["name"], sub["alt_km"], sub["speed_km_s"],
                    sub["risk_level"] if "risk_level" in sub.columns else ["SAFE"] * len(sub),
                )),
            ))

        # Anomaly rings
        if "is_anomaly" in df.columns:
            anom = df[df["is_anomaly"]]
            if not anom.empty:
                fig.add_trace(go.Scattergeo(
                    lat=anom["lat"], lon=anom["lon"], mode="markers",
                    marker=dict(size=18, color="rgba(0,0,0,0)", line=dict(color="#ff00ff", width=2)),
                    name="⚠️ Anomaly",
                    hovertemplate="<b>%{customdata}</b><br>AI anomaly detected<extra></extra>",
                    customdata=anom["name"],
                ))

        # Observer
        fig.add_trace(go.Scattergeo(
            lat=[obs_lat], lon=[obs_lon], mode="markers+text",
            marker=dict(size=12, color="#00d4ff", symbol="star"),
            text=["YOU"], textposition="top center",
            textfont=dict(color="#00d4ff", size=11), name="Observer",
        ))

        fig.update_layout(
            geo=dict(
                showland=True, landcolor="#0d1b2a",
                showocean=True, oceancolor="#050d18",
                showcountries=True, countrycolor="#1e3a5f",
                showframe=False, bgcolor="#030712",
                projection_type="orthographic",
                center=dict(lat=20, lon=80),
            ),
            paper_bgcolor="#030712",
            font=dict(color="#94a3b8", family="Share Tech Mono"),
            height=560,
            legend=dict(bgcolor="#0d1b2a", bordercolor="#1e3a5f",
                        font=dict(size=11, family="Share Tech Mono"), x=0, y=0),
            margin=dict(l=0, r=0, t=0, b=0),
        )
        st.plotly_chart(fig, use_container_width=True)

    with lc2:
        st.markdown('<div class="section-header">OBJECT LIST</div>', unsafe_allow_html=True)
        cols = ["name", "alt_km", "speed_km_s"]
        if "risk_level" in df.columns:
            cols.append("risk_level")
        disp = df[cols].copy()
        disp.columns = ["Name", "Alt(km)", "Spd(km/s)"] + (["Status"] if "risk_level" in df.columns else [])
        st.dataframe(disp, height=480, use_container_width=True, hide_index=True)
        st.markdown("""
        <div style='font-family:Share Tech Mono,monospace;font-size:0.65rem;margin-top:8px'>
        <span style='color:#00ff88'>●</span> SAFE &nbsp;
        <span style='color:#ffcc00'>●</span> MEDIUM<br>
        <span style='color:#ff8800'>●</span> HIGH &nbsp;
        <span style='color:#ff2222'>●</span> CRITICAL<br>
        <span style='color:#ff00ff'>○</span> AI ANOMALY &nbsp;
        <span style='color:#00d4ff'>★</span> YOU
        </div>""", unsafe_allow_html=True)


# ── TAB 2: COLLISION RISKS ────────────────────────────────────────────────────
with tab2:
    st.markdown('<div class="section-header">AI COLLISION RISK ANALYSIS  ·  3D ECI PROXIMITY + ML PROBABILITY</div>', unsafe_allow_html=True)

    if risk_pairs:
        critical = [p for p in risk_pairs if "CRITICAL" in p.get("Level", "")]
        high     = [p for p in risk_pairs if "HIGH"     in p.get("Level", "")]
        if critical:
            st.markdown(f'<div class="alert-critical">🚨 CRITICAL — {len(critical)} pair(s) at extreme proximity. ML models indicate elevated collision probability.</div>', unsafe_allow_html=True)
        elif high:
            st.markdown(f'<div class="alert-high">⚠️ HIGH RISK — {len(high)} pair(s) within danger threshold.</div>', unsafe_allow_html=True)

        st.dataframe(pd.DataFrame(risk_pairs), use_container_width=True, hide_index=True)

        rdf = pd.DataFrame(risk_pairs)
        fig2 = go.Figure(go.Bar(
            x=(rdf["Object A"].str[:16] + " ↔ " + rdf["Object B"].str[:16]),
            y=rdf["Distance (km)"],
            marker=dict(
                color=rdf["Distance (km)"],
                colorscale=[[0, "#ff0000"], [0.4, "#ff8800"], [0.7, "#ffcc00"], [1, "#00ff88"]],
                line=dict(color="#1e3a5f", width=1),
            ),
            text=rdf.get("ML Prob", ""),
            textposition="outside",
        ))
        fig2.update_layout(
            title="Close-Approach Distances (km)  ·  ML Collision Probability",
            paper_bgcolor="#030712", plot_bgcolor="#0d1b2a",
            font=dict(color="#94a3b8", family="Share Tech Mono", size=10),
            xaxis=dict(gridcolor="#1e3a5f", tickangle=-30),
            yaxis=dict(gridcolor="#1e3a5f", title="Distance (km)"),
            height=380,
        )
        st.plotly_chart(fig2, use_container_width=True)

        if "risk_score" in df.columns:
            fig_sc = px.scatter(
                df, x="alt_km", y="speed_km_s", color="risk_score",
                color_continuous_scale="RdYlGn_r", hover_name="name",
                title="Risk Distribution — Altitude vs Speed",
                labels={"alt_km": "Alt (km)", "speed_km_s": "Speed (km/s)", "risk_score": "Risk"},
            )
            fig_sc.update_layout(paper_bgcolor="#030712", plot_bgcolor="#0d1b2a",
                                  font=dict(color="#94a3b8"), height=360)
            st.plotly_chart(fig_sc, use_container_width=True)
    else:
        st.markdown(f'<div class="alert-safe">✅ ALL CLEAR — No objects within {collision_thresh} km. Orbital environment nominal.</div>', unsafe_allow_html=True)
        fig3 = go.Figure(go.Histogram(
            x=df["alt_km"], nbinsx=25,
            marker=dict(color="#00ff88", line=dict(color="#030712", width=0.5)),
        ))
        fig3.add_vline(x=400,  line_dash="dot", line_color="#00d4ff", annotation_text="ISS ~400km",     annotation_font_color="#00d4ff")
        fig3.add_vline(x=550,  line_dash="dot", line_color="#ffcc00", annotation_text="Starlink ~550km", annotation_font_color="#ffcc00")
        fig3.add_vline(x=2000, line_dash="dot", line_color="#ff8800", annotation_text="MEO boundary",   annotation_font_color="#ff8800")
        fig3.update_layout(
            title="Altitude Distribution", paper_bgcolor="#030712", plot_bgcolor="#0d1b2a",
            font=dict(color="#94a3b8", family="Share Tech Mono"),
            xaxis=dict(gridcolor="#1e3a5f", title="Altitude (km)"),
            yaxis=dict(gridcolor="#1e3a5f", title="Count"),
            height=380,
        )
        st.plotly_chart(fig3, use_container_width=True)


# ── TAB 3: TRAJECTORY AI ──────────────────────────────────────────────────────
with tab3:
    st.markdown('<div class="section-header">AI TRAJECTORY PREDICTION  ·  SGP4 PROPAGATION + ANOMALY DETECTION</div>', unsafe_allow_html=True)

    # Use cached TLEs — no extra network call
    sats_list = cached_fetch_tle(group_key)
    sat_names = [s["name"] for s in sats_list[:40]]

    tc1, tc2 = st.columns([2, 1])
    with tc1:
        selected = st.multiselect(
            "Select objects to predict (max 4):",
            sat_names,
            default=sat_names[:min(3, len(sat_names))],
        )
    with tc2:
        show_anom = st.toggle("Show Anomaly Points", value=True)

    st.markdown("""
    <div class="info-box">
    ℹ️ Each satellite's full 90-min ground track is computed using the same SGP4
    algorithm used by NASA/NORAD. Magenta rings = Isolation Forest anomalies.
    </div>""", unsafe_allow_html=True)

    if st.button("🔮  RUN TRAJECTORY PREDICTION"):
        if not selected:
            st.warning("Select at least one satellite.")
        else:
            # ── Compute trajectories — store in session_state to avoid double computation
            traj_cache = {}
            colors = ["#00ff88", "#00d4ff", "#ff8800", "#ff00ff"]

            prog = st.progress(0, text="Computing trajectories...")
            for idx, sname in enumerate(selected[:4]):
                sat_d = next((s for s in sats_list if s["name"] == sname), None)
                if not sat_d:
                    continue
                prog.progress((idx + 0.5) / len(selected[:4]), text=f"Propagating {sname}...")
                # predict_trajectory now includes anomaly detection internally
                tdf = predict_trajectory(sat_d, minutes=pred_minutes, step=2)
                if not tdf.empty:
                    traj_cache[sname] = tdf
                prog.progress((idx + 1) / len(selected[:4]))
            prog.empty()

            if not traj_cache:
                st.error("Could not compute trajectories. TLE data may be invalid.")
                st.stop()

            # ── Ground track map (uses cached traj — NOT recomputed)
            fig_t = go.Figure()
            for idx, (sname, tdf) in enumerate(traj_cache.items()):
                col = colors[idx % 4]

                fig_t.add_trace(go.Scattergeo(
                    lat=tdf["lat"], lon=tdf["lon"], mode="lines",
                    line=dict(color=col, width=2.5), opacity=0.85, name=sname,
                    hovertemplate=(
                        f"<b>{sname}</b><br>"
                        "T+%{customdata[0]}min | %{customdata[1]}<br>"
                        "Alt: %{customdata[2]}km  Speed: %{customdata[3]} km/s"
                        "<extra></extra>"
                    ),
                    customdata=list(zip(
                        tdf["min_ahead"], tdf["time_utc"],
                        tdf["alt_km"], tdf["speed_km_s"],
                    )),
                ))
                # Current position marker (T+0)
                fig_t.add_trace(go.Scattergeo(
                    lat=[tdf.iloc[0]["lat"]], lon=[tdf.iloc[0]["lon"]],
                    mode="markers",
                    marker=dict(size=14, color=col, symbol="star",
                                line=dict(color="white", width=1)),
                    name=f"NOW: {sname}", showlegend=False,
                ))
                # Anomaly rings
                if show_anom and "is_anomaly" in tdf.columns:
                    ap = tdf[tdf["is_anomaly"]]
                    if not ap.empty:
                        fig_t.add_trace(go.Scattergeo(
                            lat=ap["lat"], lon=ap["lon"], mode="markers",
                            marker=dict(size=14, color="rgba(0,0,0,0)",
                                        line=dict(color="#ff00ff", width=2.5)),
                            name=f"⚠️ Anomaly: {sname}", showlegend=True,
                            hovertemplate=(
                                f"<b>{sname} — AI ANOMALY</b><br>"
                                "T+%{customdata[0]}min | %{customdata[1]}<br>"
                                "Score: %{customdata[2]}<extra></extra>"
                            ),
                            customdata=list(zip(
                                ap["min_ahead"], ap["time_utc"],
                                ap.get("anomaly_score", [0]*len(ap)),
                            )),
                        ))

            fig_t.update_layout(
                geo=dict(
                    showland=True, landcolor="#0d1b2a",
                    showocean=True, oceancolor="#050d18",
                    showcountries=True, countrycolor="#1e3a5f",
                    showframe=False, bgcolor="#030712",
                    projection_type="natural earth",
                ),
                title=dict(
                    text=f"Predicted Ground Tracks — Next {pred_minutes} min  ·  SGP4",
                    font=dict(family="Orbitron", color="#00d4ff", size=13),
                ),
                paper_bgcolor="#030712",
                font=dict(color="#94a3b8", family="Share Tech Mono"),
                height=540,
                legend=dict(bgcolor="#0d1b2a", bordercolor="#1e3a5f"),
                margin=dict(l=0, r=0, t=40, b=0),
            )
            st.plotly_chart(fig_t, use_container_width=True)

            # ── Altitude profile (uses SAME cached data — no second SGP4 run)
            st.markdown('<div class="section-header">ALTITUDE & SPEED PROFILE</div>', unsafe_allow_html=True)
            ac1, ac2 = st.columns(2)

            with ac1:
                fig_alt = go.Figure()
                for idx, (sname, tdf) in enumerate(traj_cache.items()):
                    fig_alt.add_trace(go.Scatter(
                        x=tdf["min_ahead"], y=tdf["alt_km"],
                        mode="lines", name=sname,
                        line=dict(color=colors[idx % 4], width=2),
                        hovertemplate="<b>" + sname + "</b><br>T+%{x}min → %{y}km<extra></extra>",
                    ))
                fig_alt.update_layout(
                    title="Altitude (km) vs Time", paper_bgcolor="#030712", plot_bgcolor="#0d1b2a",
                    font=dict(color="#94a3b8", family="Share Tech Mono"),
                    xaxis=dict(title="Minutes Ahead", gridcolor="#1e3a5f"),
                    yaxis=dict(title="Altitude (km)", gridcolor="#1e3a5f"),
                    legend=dict(bgcolor="#0d1b2a"), height=280,
                )
                st.plotly_chart(fig_alt, use_container_width=True)

            with ac2:
                fig_spd = go.Figure()
                for idx, (sname, tdf) in enumerate(traj_cache.items()):
                    fig_spd.add_trace(go.Scatter(
                        x=tdf["min_ahead"], y=tdf["speed_km_s"],
                        mode="lines", name=sname,
                        line=dict(color=colors[idx % 4], width=2),
                        hovertemplate="<b>" + sname + "</b><br>T+%{x}min → %{y} km/s<extra></extra>",
                    ))
                fig_spd.update_layout(
                    title="Speed (km/s) vs Time", paper_bgcolor="#030712", plot_bgcolor="#0d1b2a",
                    font=dict(color="#94a3b8", family="Share Tech Mono"),
                    xaxis=dict(title="Minutes Ahead", gridcolor="#1e3a5f"),
                    yaxis=dict(title="Speed (km/s)", gridcolor="#1e3a5f"),
                    legend=dict(bgcolor="#0d1b2a"), height=280,
                )
                st.plotly_chart(fig_spd, use_container_width=True)

            # ── Anomaly summary table
            anom_rows = []
            for sname, tdf in traj_cache.items():
                if "is_anomaly" in tdf.columns:
                    ap = tdf[tdf["is_anomaly"]]
                    for _, row in ap.iterrows():
                        anom_rows.append({
                            "Satellite": sname,
                            "T+ (min)":  row["min_ahead"],
                            "Time (UTC)": row["time_utc"],
                            "Alt (km)":  row["alt_km"],
                            "Score":     row.get("anomaly_score", "—"),
                        })
            if anom_rows:
                st.markdown('<div class="section-header" style="margin-top:8px">DETECTED ANOMALIES ON TRAJECTORY</div>', unsafe_allow_html=True)
                st.dataframe(pd.DataFrame(anom_rows), use_container_width=True, hide_index=True)
    else:
        st.info("⬆️  Select satellites above and click **RUN TRAJECTORY PREDICTION**")


# ── TAB 4: OVERPASS FINDER ────────────────────────────────────────────────────
with tab4:
    st.markdown('<div class="section-header">SATELLITE OVERPASS PREDICTOR  ·  ECI → AzEl COORDINATE TRANSFORM</div>', unsafe_allow_html=True)

    st.markdown("""
    <div class="info-box">
    ℹ️ Overpass times are computed using the correct ECI→SEZ→AzEl coordinate transform
    (same method as Heavens-Above and NASA Orbital Viewer). All times are in UTC.
    GEO satellites (GOES, Himawari, Meteosat) are stationary — they don't "pass over".
    </div>""", unsafe_allow_html=True)

    ov_c1, ov_c2, ov_c3 = st.columns([1, 1, 1])
    with ov_c1:
        op_lat = st.number_input("Observer Latitude",  value=obs_lat,  min_value=-90.0,  max_value=90.0,  step=0.01, key="op_lat", format="%.4f")
    with ov_c2:
        op_lon = st.number_input("Observer Longitude", value=obs_lon,  min_value=-180.0, max_value=180.0, step=0.01, key="op_lon", format="%.4f")
    with ov_c3:
        op_min_el = st.number_input("Min Elevation (°)", value=10.0, min_value=0.0, max_value=89.0, step=1.0, key="op_min_el")

    st.markdown(
        f'<div style="font-family:Share Tech Mono,monospace;font-size:0.78rem;color:#4a9eff;margin-bottom:8px">'
        f'📍 Observer: <b style="color:#00ff88">{op_lat:.4f}°N  {op_lon:.4f}°E</b> · '
        f'Min elevation: <b style="color:#00ff88">{op_min_el:.0f}°</b></div>',
        unsafe_allow_html=True,
    )

    oc1, oc2 = st.columns([2, 1])
    with oc1:
        # Use cached TLEs — avoid duplicate network call
        sats_list2 = cached_fetch_tle(group_key)
        op_name = st.selectbox("Select satellite:", [s["name"] for s in sats_list2[:50]])
    with oc2:
        op_hours = st.slider("Search window (hours)", 6, 72, 24)

    if st.button("📡  FIND OVERPASSES"):
        sat_d = next((s for s in sats_list2 if s["name"] == op_name), None)
        if not sat_d:
            st.error("Satellite data not found.")
        else:
            with st.spinner(f"Computing overpasses for {op_name} over next {op_hours}h..."):
                passes = find_overpasses(
                    sat_d, op_lat, op_lon,
                    hours=op_hours,
                    min_elevation=op_min_el,
                )

            if passes:
                st.success(f"✅  Found **{len(passes)}** overpass(es) in next {op_hours} hours")

                pass_df = pd.DataFrame([{
                    "Start (UTC)":    p["start_utc"],
                    "End (UTC)":      p.get("end_utc", "—"),
                    "Max Elev (°)":   p["max_elevation_deg"],
                    "Peak Time":      p.get("max_el_time_utc", "—"),
                    "Duration (min)": p["duration_min"],
                    "Start Az (°)":   p["azimuth_deg"],
                    "Range (km)":     p.get("range_km", "—"),
                    "Visibility": (
                        "✅ GREAT" if p["max_elevation_deg"] > 45 else
                        "👍 GOOD"  if p["max_elevation_deg"] > 30 else
                        "⚡ FAIR"  if p["max_elevation_deg"] > 15 else
                        "👁️ LOW"
                    ),
                } for p in passes])

                st.dataframe(pass_df, use_container_width=True, hide_index=True)

                # ── Ground-track map for next 4 passes
                st.markdown('<div class="section-header" style="margin-top:16px">GROUND TRACK — NEXT PASSES</div>', unsafe_allow_html=True)

                fig_ov = go.Figure()
                colors_ov = ["#00ff88", "#00d4ff", "#ff8800", "#ff00ff",
                             "#ffcc00", "#a855f7", "#ec4899", "#22d3ee"]

                from sgp4.api import Satrec as _Satrec, jday as _jday
                from data_fetcher import eci_to_geodetic as _etg

                for pidx, p in enumerate(passes[:4]):
                    start_dt = p["start_dt"]
                    dur      = p["duration_min"]
                    col_ov   = colors_ov[pidx % len(colors_ov)]
                    label    = f"Pass {pidx+1}: {p['start_utc']} (max {p['max_elevation_deg']}°)"

                    # Compute track ±2 min around pass (use same sgp4 object)
                    track_rows = []
                    try:
                        _sat = _Satrec.twoline2rv(sat_d["tle1"], sat_d["tle2"])
                        t_cur = start_dt - timedelta(minutes=2)
                        t_end = start_dt + timedelta(minutes=dur + 2)
                        while t_cur <= t_end:
                            _jd, _fr = _jday(t_cur.year, t_cur.month, t_cur.day,
                                             t_cur.hour, t_cur.minute, t_cur.second)
                            _e, _r, _ = _sat.sgp4(_jd, _fr)
                            if _e == 0:
                                _lat, _lon, _alt = _etg(_r, _jd + _fr)
                                track_rows.append({
                                    "lat": _lat, "lon": _lon, "alt": round(_alt, 1),
                                    "t": t_cur.strftime("%H:%M UTC"),
                                })
                            t_cur += timedelta(minutes=1)
                    except Exception:
                        pass

                    if track_rows:
                        tdf_ov = pd.DataFrame(track_rows)
                        fig_ov.add_trace(go.Scattergeo(
                            lat=tdf_ov["lat"], lon=tdf_ov["lon"],
                            mode="lines+markers",
                            line=dict(color=col_ov, width=2.5),
                            marker=dict(size=4, color=col_ov),
                            name=label,
                            hovertemplate=(
                                "<b>" + label + "</b><br>"
                                "Lat:%{lat:.2f}° Lon:%{lon:.2f}°<br>"
                                "Alt: %{customdata[0]} km  Time: %{customdata[1]}<extra></extra>"
                            ),
                            customdata=list(zip(tdf_ov["alt"], tdf_ov["t"])),
                            opacity=0.85,
                        ))
                        # Mark pass start with triangle
                        vis_start = track_rows[min(2, len(track_rows)-1)]
                        fig_ov.add_trace(go.Scattergeo(
                            lat=[vis_start["lat"]], lon=[vis_start["lon"]],
                            mode="markers",
                            marker=dict(size=14, color=col_ov, symbol="triangle-up",
                                        line=dict(color="white", width=1.5)),
                            showlegend=False,
                            hovertemplate=f"<b>Pass {pidx+1} starts</b><br>{vis_start['t']}<extra></extra>",
                        ))

                # Observer marker
                fig_ov.add_trace(go.Scattergeo(
                    lat=[op_lat], lon=[op_lon],
                    mode="markers+text",
                    marker=dict(size=14, color="#00d4ff", symbol="star",
                                line=dict(color="white", width=1.5)),
                    text=["YOU"], textposition="top right",
                    textfont=dict(color="#00d4ff", size=12, family="Share Tech Mono"),
                    name="Observer",
                    hovertemplate=f"Observer<br>{op_lat:.4f}°N  {op_lon:.4f}°E<extra></extra>",
                ))

                fig_ov.update_layout(
                    geo=dict(
                        showland=True, landcolor="#0d1b2a",
                        showocean=True, oceancolor="#050d18",
                        showcountries=True, countrycolor="#1e3a5f",
                        showcoastlines=True, coastlinecolor="#1e3a5f",
                        showframe=False, bgcolor="#030712",
                        projection_type="natural earth",
                        center=dict(lat=op_lat, lon=op_lon),
                        lataxis_range=[max(op_lat - 60, -90), min(op_lat + 60, 90)],
                        lonaxis_range=[op_lon - 80, op_lon + 80],
                    ),
                    paper_bgcolor="#030712",
                    font=dict(color="#94a3b8", family="Share Tech Mono"),
                    height=520,
                    legend=dict(bgcolor="#0d1b2a", bordercolor="#1e3a5f",
                                font=dict(size=10, family="Share Tech Mono")),
                    margin=dict(l=0, r=0, t=10, b=0),
                    title=dict(
                        text=f"Overpass Ground Tracks — {op_name}",
                        font=dict(family="Orbitron", color="#00d4ff", size=13),
                    ),
                )
                st.plotly_chart(fig_ov, use_container_width=True)

                # ── Elevation bar chart
                st.markdown('<div class="section-header" style="margin-top:8px">MAX ELEVATION PER PASS</div>', unsafe_allow_html=True)
                fig_el = go.Figure(go.Bar(
                    x=[f"Pass {i+1}<br>{p['start_utc']}" for i, p in enumerate(passes)],
                    y=pass_df["Max Elev (°)"],
                    marker=dict(
                        color=pass_df["Max Elev (°)"],
                        colorscale=[[0, "#1e3a5f"], [0.3, "#00d4ff"], [0.7, "#00ff88"], [1, "#ffffff"]],
                        line=dict(color="#1e3a5f", width=1),
                    ),
                    text=[f"{v}°  {vis}" for v, vis in zip(pass_df["Max Elev (°)"], pass_df["Visibility"])],
                    textposition="outside",
                    textfont=dict(family="Share Tech Mono", size=10),
                ))
                fig_el.add_hline(y=45, line_dash="dot", line_color="#00ff88",
                                  annotation_text="Great (45°)", annotation_font_color="#00ff88")
                fig_el.add_hline(y=30, line_dash="dot", line_color="#00d4ff",
                                  annotation_text="Good (30°)", annotation_font_color="#00d4ff")
                fig_el.add_hline(y=op_min_el, line_dash="dot", line_color="#ff8800",
                                  annotation_text=f"Min threshold ({op_min_el:.0f}°)",
                                  annotation_font_color="#ff8800")
                fig_el.update_layout(
                    paper_bgcolor="#030712", plot_bgcolor="#0d1b2a",
                    font=dict(color="#94a3b8", family="Share Tech Mono"),
                    xaxis=dict(gridcolor="#1e3a5f", tickangle=-20),
                    yaxis=dict(gridcolor="#1e3a5f", title="Max Elevation (°)", range=[0, 95]),
                    height=350,
                )
                st.plotly_chart(fig_el, use_container_width=True)

            else:
                st.warning(
                    f"⚠️ No passes above **{op_min_el:.0f}°** elevation for **{op_name}** "
                    f"over the next **{op_hours}h** from ({op_lat:.2f}°, {op_lon:.2f}°).  \n\n"
                    "**Suggestions:**\n"
                    "- Try a longer search window (48–72 hours)\n"
                    "- Lower the minimum elevation (try 5°)\n"
                    "- GEO satellites (GOES, Himawari, Meteosat) never pass overhead\n"
                    "- LEO satellites (ISS, Starlink, NOAA) pass 4–6 times per day\n"
                    "- Try **Space Stations** group and select ISS for best results"
                )


# ── TAB 5: ANALYTICS ─────────────────────────────────────────────────────────
with tab5:
    st.markdown('<div class="section-header">FLEET ANALYTICS & AI INSIGHTS</div>', unsafe_allow_html=True)

    ac1, ac2 = st.columns(2)

    with ac1:
        fig_pie = go.Figure(go.Pie(
            labels=["LEO (<2000km)", "MEO (2000–35786km)", "GEO (>35786km)"],
            values=[
                max(stats.get("leo_count", 1), 1),
                max(stats.get("meo_count", 0), 1),
                max(stats.get("geo_count", 0), 1),
            ],
            hole=0.55,
            marker=dict(
                colors=["#00ff88", "#00d4ff", "#7c3aed"],
                line=dict(color="#030712", width=2),
            ),
        ))
        fig_pie.update_layout(
            title="Orbit Zone Distribution",
            paper_bgcolor="#030712",
            font=dict(color="#94a3b8", family="Share Tech Mono"),
            legend=dict(bgcolor="#0d1b2a"),
            height=340,
        )
        st.plotly_chart(fig_pie, use_container_width=True)

    with ac2:
        fig_spd2 = go.Figure(go.Histogram(
            x=df["speed_km_s"], nbinsx=20,
            marker=dict(color="#00d4ff", line=dict(color="#030712", width=0.5)),
            opacity=0.85,
        ))
        fig_spd2.update_layout(
            title="Orbital Speed Distribution",
            paper_bgcolor="#030712", plot_bgcolor="#0d1b2a",
            font=dict(color="#94a3b8", family="Share Tech Mono"),
            xaxis=dict(title="Speed (km/s)", gridcolor="#1e3a5f"),
            yaxis=dict(title="Count", gridcolor="#1e3a5f"),
            height=340,
        )
        st.plotly_chart(fig_spd2, use_container_width=True)

    if "is_anomaly" in df.columns and df["is_anomaly"].any():
        st.markdown('<div class="section-header" style="margin-top:8px">AI-FLAGGED ANOMALIES (ISOLATION FOREST)</div>', unsafe_allow_html=True)
        adf = df[df["is_anomaly"]][["name", "alt_km", "speed_km_s", "lat", "lon", "anomaly_score"]].copy()
        adf.columns = ["Name", "Alt(km)", "Speed(km/s)", "Lat", "Lon", "Anomaly Score"]
        st.dataframe(
            adf.sort_values("Anomaly Score", ascending=False),
            use_container_width=True, hide_index=True,
        )

    st.markdown('<div class="section-header" style="margin-top:8px">ORBITAL PARAMETER MAP</div>', unsafe_allow_html=True)
    color_col = "risk_score" if "risk_score" in df.columns else "alt_km"
    fig_map = px.scatter(
        df, x="alt_km", y="speed_km_s", color=color_col,
        hover_name="name", color_continuous_scale="Plasma",
        title="Altitude vs Speed — All Tracked Objects",
        labels={"alt_km": "Alt (km)", "speed_km_s": "Speed (km/s)", color_col: "Risk"},
    )
    fig_map.update_layout(
        paper_bgcolor="#030712", plot_bgcolor="#0d1b2a",
        font=dict(color="#94a3b8", family="Share Tech Mono"),
        height=400,
    )
    st.plotly_chart(fig_map, use_container_width=True)


# ══════════════════════════════════════════════════════════════════════════════
# AUTO REFRESH — non-blocking
# ══════════════════════════════════════════════════════════════════════════════
if auto_refresh:
    # Store last refresh time in session_state to avoid blocking
    if "last_refresh" not in st.session_state:
        st.session_state.last_refresh = time.time()

    elapsed = time.time() - st.session_state.last_refresh
    remaining = max(0, 30 - int(elapsed))

    st.sidebar.markdown(
        f'<div style="font-family:Share Tech Mono,monospace;font-size:0.65rem;'
        f'color:#00ff8888;text-align:center">⟳ Next refresh in {remaining}s</div>',
        unsafe_allow_html=True,
    )

    if elapsed >= 30:
        st.session_state.last_refresh = time.time()
        st.cache_data.clear()
        st.rerun()
    else:
        # Re-check every 5 seconds using meta refresh trick
        time.sleep(min(5, remaining + 0.1))
        st.rerun()
